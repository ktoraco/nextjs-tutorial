export default function CustomersPage() {
  return <p>Customers Page</p>;
}
